import type { Transition } from 'framer-motion'

/** Strong ease-out (entrate) e ease-in-out (movimenti on-screen), dalle linee guida di Emil Kowalski */
export const ease = [0.23, 1, 0.32, 1] as const
export const easeInOut = [0.77, 0, 0.175, 1] as const

/** Molla "Apple-style": interrompibile, senza rimbalzo eccessivo */
export const spring: Transition = { type: 'spring', duration: 0.5, bounce: 0.15 }
export const softSpring = { stiffness: 150, damping: 20, mass: 0.5 }
