import { AnimatePresence, MotionConfig } from 'framer-motion'
import { useCallback, useState } from 'react'
import Preloader from './components/layout/Preloader'
import Navbar from './components/layout/Navbar'
import Footer from './components/layout/Footer'
import Grain from './components/layout/Grain'
import ScrollProgress from './components/layout/ScrollProgress'
import Hero from './sections/Hero'
import ZoomReveal from './sections/ZoomReveal'
import Manifesto from './sections/Manifesto'
import DishMarquee from './sections/DishMarquee'
import Story from './sections/Story'
import Pizzeria from './sections/Pizzeria'
import Specialties from './sections/Specialties'
import Spaces from './sections/Spaces'
import Services from './sections/Services'
import GiftCards from './sections/GiftCards'
import Reviews from './sections/Reviews'
import Location from './sections/Location'

const INTRO_KEY = 'gep-intro-seen'

/** L'intro si vede una volta per sessione e mai con "riduci movimento" attivo */
function shouldPlayIntro() {
  try {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return false
    if (sessionStorage.getItem(INTRO_KEY)) return false
    sessionStorage.setItem(INTRO_KEY, '1')
  } catch {
    /* storage non disponibile: mostra comunque l'intro */
  }
  return true
}

export default function App() {
  const [loading, setLoading] = useState(shouldPlayIntro)
  const done = useCallback(() => setLoading(false), [])

  return (
    <MotionConfig reducedMotion="user">
      <AnimatePresence>{loading && <Preloader key="preloader" onDone={done} />}</AnimatePresence>
      <a href="#cucina" className="fixed left-4 top-4 z-[90] -translate-y-24 rounded-full bg-ink px-5 py-3 text-sm font-semibold text-paper focus-visible:translate-y-0">
        Vai al menu
      </a>
      <ScrollProgress />
      <Navbar ready={!loading} />
      <main>
        <Hero ready={!loading} />
        <ZoomReveal />
        <Manifesto />
        <DishMarquee />
        <Story />
        <Pizzeria />
        <Specialties />
        <Spaces />
        <Services />
        <GiftCards />
        <Reviews />
        <Location />
      </main>
      <Footer />
      <Grain />
    </MotionConfig>
  )
}
