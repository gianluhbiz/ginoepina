import { motion, useScroll, useTransform, type Variants } from 'framer-motion'
import { useRef, type ReactNode } from 'react'
import { site } from '../data/site'
import { platforms } from '../data/reviews'
import { photos } from '../lib/images'
import { ease } from '../lib/motion'
import { usePauseOffscreen } from '../hooks/usePauseOffscreen'
import { cn } from '../lib/cn'
import ArrowLink from '../components/ui/ArrowLink'

/**
 * Momento firmato della pagina: il nome "si impiatta".
 * Le parole salgono da sotto la linea, poi i piatti si aprono dentro le lettere.
 */
const word = (delay: number): Variants => ({
  hidden: { transform: 'translateY(105%)' },
  show: { transform: 'translateY(0%)', transition: { duration: 0.9, ease, delay } },
})

const plate = (delay: number): Variants => ({
  hidden: { clipPath: 'inset(0% 50% 0% 50% round 999px)' },
  show: { clipPath: 'inset(0% 0% 0% 0% round 999px)', transition: { duration: 0.8, ease, delay } },
})

const plateImg = (delay: number): Variants => ({
  hidden: { transform: 'scale(1.5)', filter: 'blur(6px)' },
  show: { transform: 'scale(1)', filter: 'blur(0px)', transition: { duration: 1.1, ease, delay } },
})

function Word({ children, delay, className = '' }: { children: ReactNode; delay: number; className?: string }) {
  return (
    <span className="inline-block overflow-hidden pb-[0.06em] align-bottom">
      <motion.span className={cn('inline-block', className)} variants={word(delay)}>
        {children}
      </motion.span>
    </span>
  )
}

function Pill({ src, delay, className = '' }: { src: string; delay: number; className?: string }) {
  return (
    <motion.span className={cn('relative mx-[0.08em] inline-block h-[0.72em] overflow-hidden rounded-full align-middle', className)} variants={plate(delay)}>
      <motion.img src={src} alt="" className="absolute inset-0 h-full w-full object-cover" variants={plateImg(delay)} />
    </motion.span>
  )
}

function RotatingBadge({ playState }: { playState: string }) {
  const text = 'Pizzeria · Forno a legna · Cucina sannita · Enoteca · '
  return (
    <div className="relative grid size-32 place-items-center md:size-40">
      <svg viewBox="0 0 200 200" className={cn('absolute inset-0 size-full animate-spin-slow motion-reduce:animate-none', playState)} aria-hidden>
        <defs>
          <path id="circle" d="M100,100 m-78,0 a78,78 0 1,1 156,0 a78,78 0 1,1 -156,0" />
        </defs>
        <text className="fill-ink text-[15px] font-semibold uppercase tracking-[0.2em]">
          <textPath href="#circle">{text}</textPath>
        </text>
      </svg>
      <span className="grid size-14 place-items-center rounded-full bg-tomato text-2xl text-paper md:size-16">
        <i className="ri-fire-line" aria-hidden />
      </span>
    </div>
  )
}

export default function Hero({ ready }: { ready: boolean }) {
  const ref = useRef<HTMLElement>(null)
  const { ref: loopRef, playState } = usePauseOffscreen<HTMLDivElement>()
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] })
  const titleY = useTransform(scrollYProgress, [0, 1], ['0%', '25%'])
  const google = platforms[0]

  return (
    <section id="top" ref={ref} className="relative overflow-hidden bg-paper px-4 pb-10 pt-28 text-ink md:px-8 md:pt-36">
      <motion.div ref={loopRef} initial="hidden" animate={ready ? 'show' : 'hidden'} className="mx-auto max-w-[1600px]">
        <motion.h1
          style={{ y: titleY }}
          aria-label="Gino e Pina, dal 1940"
          className="font-display text-[19vw] font-medium leading-[0.86] tracking-[-0.04em] [text-wrap:nowrap] md:text-[12.5vw]"
        >
          <span aria-hidden className="block whitespace-nowrap">
            <Word delay={0}>Gino</Word>
            <Pill src={photos.pizzaBanner} delay={0.35} className="w-[0.9em] md:w-[2.4em]" />
          </span>
          <span aria-hidden className="block whitespace-nowrap md:pl-[1.4em]">
            <Word delay={0.08} className="font-light italic text-tomato">e</Word>{' '}
            <Word delay={0.14}>Pina</Word>
            <motion.span
              className="relative ml-[0.15em] hidden size-[0.72em] overflow-hidden rounded-full align-middle md:inline-block"
              variants={{
                hidden: { opacity: 0, transform: 'scale(0.9) rotate(-30deg)' },
                show: { opacity: 1, transform: 'scale(1) rotate(0deg)', transition: { duration: 0.9, ease, delay: 0.5 } },
              }}
            >
              <img src={photos.pizzaTop} alt="" className={cn('h-full w-full animate-spin-slow object-cover motion-reduce:animate-none', playState)} />
            </motion.span>
          </span>
          <span aria-hidden className="block whitespace-nowrap text-right">
            <Pill src={photos.orecchiette} delay={0.45} className="w-[0.9em] md:w-[2.2em]" />
            <Word delay={0.2} className="font-light italic">dal</Word>{' '}
            <Word delay={0.26} className="tabular-nums">1940</Word>
          </span>
        </motion.h1>

        <motion.div
          variants={{ hidden: { opacity: 0 }, show: { opacity: 1, transition: { delay: 0.7, duration: 0.6, ease } } }}
          className="mt-12 grid items-end gap-8 md:mt-16 md:grid-cols-12"
        >
          <p className="max-w-md text-lg leading-relaxed text-ink/80 md:col-span-5">
            {site.intro} <span className="font-display italic text-ink">{site.claim}.</span>
          </p>

          <div className="flex flex-wrap gap-3 md:col-span-4">
            <ArrowLink href={site.phone.href} variant="tomato" icon="ri-phone-line">Prenota un tavolo</ArrowLink>
            <ArrowLink href="#cucina" variant="outline" icon="ri-arrow-down-line">Il menu</ArrowLink>
          </div>

          <div className="flex items-center justify-between gap-6 md:col-span-3 md:justify-end">
            <a href={google.href} target="_blank" rel="noreferrer" className="group">
              <span className="flex items-baseline gap-2">
                <span className="font-display text-5xl font-light tabular-nums">{google.rating}</span>
                <span className="flex text-gold" aria-label="4 stelle su 5">
                  {Array.from({ length: 4 }).map((_, i) => <i key={i} className="ri-star-fill" aria-hidden />)}
                  <i className="ri-star-line" aria-hidden />
                </span>
              </span>
              <span className="text-sm text-ink/70 underline-offset-4 group-hover:underline">{google.count} su Google</span>
            </a>
            <RotatingBadge playState={playState} />
          </div>
        </motion.div>

        <motion.p
          variants={{ hidden: { opacity: 0 }, show: { opacity: 1, transition: { delay: 0.9, duration: 0.6 } } }}
          className="mt-10 flex flex-wrap justify-between gap-2 border-t border-ink/15 pt-4 text-sm text-ink/70"
        >
          <span>Ristorante, pizzeria, enoteca e caffetteria</span>
          <span>
            <i className="ri-map-pin-2-line mr-1 text-tomato" aria-hidden />
            {site.address.street}, Benevento
          </span>
        </motion.p>
      </motion.div>
    </section>
  )
}
