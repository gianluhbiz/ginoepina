// Scarica in /public/images tutte le foto usate dal sito (ginoepina.it e Scoutmenu).
// Uso: npm run images — poi in src/lib/images.ts imposta SITE_BASE = '/images/site/' e MENU_BASE = '/images/menu/'.
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const SITE = 'https://www.ginoepina.it/wp-content/uploads/'
const MENU = 'https://www.scoutmenu.it/immagini/piatti/'

async function walk(dir) {
  const out = []
  for (const e of await readdir(dir, { withFileTypes: true })) {
    const p = join(dir, e.name)
    if (e.isDirectory()) out.push(...(await walk(p)))
    else if (/\.(ts|tsx)$/.test(e.name)) out.push(p)
  }
  return out
}

const jobs = new Map()
for (const f of await walk(join(root, 'src'))) {
  const src = await readFile(f, 'utf8')
  for (const m of src.matchAll(/site\('([^']+)'\)/g)) jobs.set(SITE + m[1], join(root, 'public/images/site', m[1]))
  for (const m of src.matchAll(/(?:img: |menuPhoto\()'([^']+\.(?:jpe?g|png|webp))'/gi)) jobs.set(MENU + m[1], join(root, 'public/images/menu', m[1]))
}

for (const [url, dest] of jobs) {
  const res = await fetch(url)
  if (!res.ok) { console.warn('✗', url, res.status); continue }
  await mkdir(dirname(dest), { recursive: true })
  await writeFile(dest, Buffer.from(await res.arrayBuffer()))
  console.log('✓', url)
}
console.log(`Fatto: ${jobs.size} immagini.`)
