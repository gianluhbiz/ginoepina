# Gino e Pina — sito web

Ristorante · Pizzeria · Enoteca a Benevento, dal 1940. Home + pagina **/menu**, in italiano e inglese.

React 19 + TypeScript + Vite · **Tailwind CSS v4** (unico sistema di stile) · **framer-motion** · **Remix Icon** · **react-router** · font Archivo self-hosted (@fontsource).

```bash
npm install          # installa anche react-router e @fontsource-variable/archivo
npm run dev
npm run build        # → dist/
npm run images       # (opzionale) scarica le foto in public/images
```

## Struttura

```
src/
├── main.tsx              # router + lingua
├── App.tsx               # layout comune e rotte (/ , /menu, 404)
├── index.css             # token del tema "Insegna smaltata"
├── i18n/                 # contesto lingua IT/EN + testi dell'interfaccia
├── types/
├── data/
│   ├── menu.ts           # MENU COMPLETO con prezzi e allergeni (da aggiornare qui)
│   ├── site.ts           # contatti, orari, WhatsApp, mappa, valutazioni
│   └── content.ts        # sale, recensioni, FAQ
├── lib/                  # immagini, prezzi, curve di animazione
├── hooks/                # aperto/chiuso in tempo reale (ora di Benevento), blocco scroll
├── components/
│   ├── layout/           # Header, Footer, barra azioni mobile, lingua, scroll
│   └── ui/               # Plate (targa), Button, SignHeading, StatusPlate, MenuItemRow
├── sections/             # sezioni della home + BookingForm (WhatsApp)
└── pages/                # HomePage, MenuPage, NotFound
```

## Note
- **Menu**: trascritto dal menu digitale ufficiale su Scoutmenu (ottobre 2026). Il menu è giornaliero: i piatti segnati "stagionale" non sono sempre disponibili. Le traduzioni inglesi vanno fatte rivedere al ristorante.
- **Prenotazione**: il modulo apre WhatsApp con il messaggio già scritto (nessun server). C'è anche il link alla prenotazione online di Scoutmenu.
- **Foto**: tutte vere, caricate da ginoepina.it e scoutmenu.it. Con `npm run images` diventano locali.
- **Pubblicazione**: è una SPA con rotta `/menu`: sul server serve il fallback a `index.html` (Netlify `_redirects`, Vercel lo fa da solo).
- **Design**: regole in `DESIGN.md`, contesto prodotto in `PRODUCT.md`. Skill Impeccable ed Emil Kowalski in `.claude/skills/`.
