import { Link } from 'react-router'
import { useLang } from '../../i18n'
import { strings } from '../../i18n/strings'
import { dayNames, hours, site } from '../../data/site'
import { navItems } from './Header'

const fmt = (r: [string, string] | null) => (r ? `${r[0]}–${r[1]}` : '—')

export default function Footer() {
  const { t } = useLang()
  return (
    <footer className="bg-green-deep pb-28 text-enamel md:pb-0">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <p className="text-3xl font-extrabold uppercase leading-none [font-stretch:72%]">
            Gino <span className="normal-case text-yellow">e</span> Pina
          </p>
          <p className="mt-3 max-w-xs text-enamel/85">{site.fullName}. Benevento, dal 1940.</p>
          <div className="mt-5 flex gap-2">
            {site.socials.map((s) => (
              <a
                key={s.label}
                href={s.href}
                target="_blank"
                rel="noreferrer"
                aria-label={s.label}
                className="grid size-11 place-items-center rounded-lg bg-green text-xl transition-[background-color,transform] duration-150 hover:bg-enamel hover:text-green active:scale-[0.95]"
              >
                <i className={s.icon} aria-hidden />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h2 className="mb-3 text-lg font-bold">{t(strings.info.contacts)}</h2>
          <ul className="space-y-1.5 text-enamel/90">
            <li>{site.address.street}</li>
            <li>{site.address.city}</li>
            <li><a className="underline-offset-4 hover:underline" href={site.phone.href}>{site.phone.display}</a></li>
            <li><a className="underline-offset-4 hover:underline" href={site.mobile.href}>{site.mobile.display}</a></li>
            <li><a className="underline-offset-4 hover:underline" href={`mailto:${site.email}`}>{site.email}</a></li>
          </ul>
        </div>

        <div>
          <h2 className="mb-3 text-lg font-bold">{t(strings.info.hours)}</h2>
          <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 text-sm tabular-nums text-enamel/90">
            {hours.map((d) => (
              <div key={d.day} className="contents">
                <dt>{t(dayNames[d.day])}</dt>
                <dd>
                  {fmt(d.lunch)} · {d.dinner ? fmt(d.dinner) : t(strings.info.closed)}
                </dd>
              </div>
            ))}
          </dl>
        </div>

        <nav aria-label="Footer">
          <h2 className="mb-3 text-lg font-bold">{t(strings.nav.menu)}</h2>
          <ul className="space-y-1.5">
            {navItems.map((n) => (
              <li key={n.to}>
                <Link to={n.to} className="text-enamel/90 underline-offset-4 hover:underline">
                  {t(n.label)}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
      <div className="border-t border-enamel/15">
        <p className="mx-auto max-w-7xl px-4 py-5 text-sm text-enamel/75 sm:px-6">
          © {new Date().getFullYear()} {site.name} · {t(strings.footer.rights)}
        </p>
      </div>
    </footer>
  )
}
