import { Route, Routes } from 'react-router'
import { MotionConfig } from 'framer-motion'
import { useLang } from './i18n'
import { strings } from './i18n/strings'
import Header from './components/layout/Header'
import Footer from './components/layout/Footer'
import MobileActionBar from './components/layout/MobileActionBar'
import ScrollManager from './components/layout/ScrollManager'
import HomePage from './pages/HomePage'
import MenuPage from './pages/MenuPage'
import NotFound from './pages/NotFound'

export default function App() {
  const { t } = useLang()
  return (
    <MotionConfig reducedMotion="user">
      <ScrollManager />
      <a href="#main" className="fixed left-3 top-3 z-50 -translate-y-24 rounded-lg bg-red px-4 py-3 font-semibold text-enamel focus-visible:translate-y-0">
        {t(strings.skip)}
      </a>
      <Header />
      <main id="main">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/menu" element={<MenuPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
      <MobileActionBar />
    </MotionConfig>
  )
}
