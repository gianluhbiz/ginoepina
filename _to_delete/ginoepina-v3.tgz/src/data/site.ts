import type { L, OpeningDay } from '../types'

const l = (it: string, en: string): L => ({ it, en })

export const site = {
  name: 'Gino e Pina',
  fullName: 'Ristorante Pizzeria Enoteca Caffetteria Gino e Pina',
  founded: 1940,
  address: { street: 'Viale dell’Università, 2', city: '82100 Benevento (BN)' },
  phone: { display: '0824 24947', href: 'tel:+39082424947' },
  mobile: { display: '347 197 2824', href: 'tel:+393471972824' },
  whatsappNumber: '393471972824',
  email: 'info@ginoepina.it',
  bookingUrl: 'https://www.scoutmenu.it/prenota-locale.php?id=1032',
  officialMenuUrl: 'https://www.scoutmenu.it/dettagli-locale.php?id=1032',
  mapsUrl: 'https://www.google.com/maps/dir/?api=1&destination=Gino+e+Pina+Viale+dell%27Universit%C3%A0+2+Benevento',
  mapsEmbed:
    'https://maps.google.com/maps?q=Gino%20e%20Pina%2C%20Viale%20dell%27Universit%C3%A0%202%2C%20Benevento&z=16&output=embed',
  socials: [
    { label: 'Instagram', icon: 'ri-instagram-line', href: 'https://www.instagram.com/ginoepina1940/' },
    { label: 'Facebook', icon: 'ri-facebook-circle-line', href: 'https://www.facebook.com/ginoepinabenevento' },
    {
      label: 'Tripadvisor',
      icon: 'ri-star-smile-line',
      href: 'https://www.tripadvisor.it/Restaurant_Review-g194690-d2474845-Reviews-Ristorante_Pizzeria_Enoteca_Gino_e_Pina-Benevento_Province_of_Benevento_Campania.html',
    },
  ],
} as const

export const whatsappLink = (text?: string) =>
  `https://wa.me/${site.whatsappNumber}${text ? `?text=${encodeURIComponent(text)}` : ''}`

/** Orari dal sito ufficiale: pranzo 12–15, cena 19–23.30; chiuso domenica sera e giovedì sera */
export const hours: OpeningDay[] = [
  { day: 1, lunch: ['12:00', '15:00'], dinner: ['19:00', '23:30'] },
  { day: 2, lunch: ['12:00', '15:00'], dinner: ['19:00', '23:30'] },
  { day: 3, lunch: ['12:00', '15:00'], dinner: ['19:00', '23:30'] },
  { day: 4, lunch: ['12:00', '15:00'], dinner: null },
  { day: 5, lunch: ['12:00', '15:00'], dinner: ['19:00', '23:30'] },
  { day: 6, lunch: ['12:00', '15:00'], dinner: ['19:00', '23:30'] },
  { day: 0, lunch: ['12:00', '15:00'], dinner: null },
]

export const dayNames: Record<number, L> = {
  0: l('Domenica', 'Sunday'),
  1: l('Lunedì', 'Monday'),
  2: l('Martedì', 'Tuesday'),
  3: l('Mercoledì', 'Wednesday'),
  4: l('Giovedì', 'Thursday'),
  5: l('Venerdì', 'Friday'),
  6: l('Sabato', 'Saturday'),
}

export const nearby: Array<{ label: L; distance: L; icon: string }> = [
  { label: l('Teatro Romano', 'Roman Theatre'), distance: l('200 m', '200 m'), icon: 'ri-ancient-pavilion-line' },
  { label: l('Centro storico', 'Old town'), distance: l('pochi passi', 'a few steps'), icon: 'ri-community-line' },
  { label: l('Corso Garibaldi, isola pedonale', 'Corso Garibaldi, pedestrian street'), distance: l('15 min a piedi', '15 min walk'), icon: 'ri-walk-line' },
  { label: l('Parco De Mita e Parco delle Streghe', 'De Mita Park and Witches’ Park'), distance: l('5 min a piedi', '5 min walk'), icon: 'ri-tree-line' },
  { label: l('Stadio “Ciro Vigorito” e PalaSannio', '“Ciro Vigorito” stadium and PalaSannio'), distance: l('15 min a piedi', '15 min walk'), icon: 'ri-football-line' },
]

export const ratings = [
  { name: 'Google', score: '4,1', scoreEn: '4.1', count: '1.308', countEn: '1,308', icon: 'ri-google-fill', href: 'https://www.google.com/maps/search/?api=1&query=Gino+e+Pina+Benevento' },
  { name: 'Tripadvisor', score: '4,1', scoreEn: '4.1', count: '659', countEn: '659', icon: 'ri-star-smile-fill', href: site.socials[2].href },
] as const
