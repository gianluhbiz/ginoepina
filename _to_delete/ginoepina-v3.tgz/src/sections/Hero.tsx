import { useLang } from '../i18n'
import { strings } from '../i18n/strings'
import { site } from '../data/site'
import { photos } from '../lib/images'
import Plate from '../components/ui/Plate'
import SignHeading from '../components/ui/SignHeading'
import StatusPlate from '../components/ui/StatusPlate'
import Button from '../components/ui/Button'
import BookingForm from './BookingForm'

export default function Hero() {
  const { t } = useLang()
  return (
    <section className="bg-mist">
      <div className="mx-auto grid max-w-7xl gap-5 px-4 py-5 sm:px-6 sm:py-8 lg:grid-cols-[1.2fr_1fr] lg:gap-6">
        <Plate tone="green" className="lg:row-span-2" innerClassName="flex flex-col gap-6 p-5 sm:p-8">
          <div>
            <SignHeading as="h1" className="text-[2.9rem] sm:text-6xl lg:text-[5.25rem]">
              {t(strings.hero.title)} <span className="block text-yellow">{t(strings.hero.titleSince)}</span>
            </SignHeading>
            <p className="mt-5 max-w-[60ch] text-lg leading-relaxed text-enamel/90">{t(strings.hero.lead)}</p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <StatusPlate />
            <Button to="/menu" variant="enamel" icon="ri-book-open-line">
              {t(strings.actions.seeMenu)}
            </Button>
          </div>
          <hr className="border-t-2 border-dashed border-enamel/25" />
          <div id="prenota" className="scroll-mt-24">
            <BookingForm />
            <p className="mt-4 text-sm text-enamel/85">
              <a href={site.bookingUrl} target="_blank" rel="noreferrer" className="font-semibold underline underline-offset-4">
                {t(strings.actions.bookOnline)}
              </a>{' '}
              · Scoutmenu
            </p>
          </div>
        </Plate>

        <figure className="relative overflow-hidden rounded-[var(--radius-plate)] bg-green p-1.5">
          <img
            src={photos.fettuccine}
            alt={t(strings.hero.photoCaption)}
            width={1920}
            height={695}
            fetchPriority="high"
            className="aspect-[4/3] h-full w-full rounded-[calc(var(--radius-plate)-5px)] object-cover lg:aspect-auto"
          />
          <figcaption className="absolute bottom-4 left-4 right-4 rounded-lg bg-green/90 px-3 py-2 text-sm font-medium text-enamel sm:right-auto">
            {t(strings.hero.photoCaption)}
          </figcaption>
        </figure>

        <figure className="grid grid-cols-[7rem_1fr] items-center gap-4 rounded-[var(--radius-plate)] bg-enamel p-1.5 ring-1 ring-green/15 sm:grid-cols-[9rem_1fr]">
          <img
            src={photos.historic}
            alt={t(strings.hero.archiveCaption)}
            loading="lazy"
            className="aspect-square w-full rounded-[calc(var(--radius-plate)-5px)] object-cover grayscale"
          />
          <figcaption className="pr-3 text-base leading-snug text-ink">
            <span className="block font-bold">{t(strings.hero.archiveCaption)}</span>
            <span className="text-muted">{t(strings.locale.strega)}</span>
          </figcaption>
        </figure>
      </div>
    </section>
  )
}
