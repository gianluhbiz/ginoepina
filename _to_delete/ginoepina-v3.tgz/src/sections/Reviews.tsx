import { useLang } from '../i18n'
import { strings } from '../i18n/strings'
import { reviews } from '../data/content'
import { ratings } from '../data/site'
import SignHeading from '../components/ui/SignHeading'
import Plate from '../components/ui/Plate'

export default function Reviews() {
  const { t, lang } = useLang()
  return (
    <section aria-labelledby="reviews-title" className="bg-enamel py-14 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SignHeading id="reviews-title" className="text-4xl text-green sm:text-5xl">{t(strings.reviews.title)}</SignHeading>

        <div className="mt-8 grid gap-5 lg:grid-cols-[0.8fr_1.2fr] lg:gap-6">
          <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1">
            {ratings.map((r) => (
              <li key={r.name}>
                <a href={r.href} target="_blank" rel="noreferrer" className="block transition-transform duration-150 active:scale-[0.98]">
                  <Plate tone="green" innerClassName="flex items-center gap-5">
                    <span className="text-6xl font-extrabold tabular-nums [font-stretch:72%]">{lang === 'it' ? r.score : r.scoreEn}</span>
                    <span>
                      <span className="flex items-center gap-2 text-lg font-bold">
                        <i className={`${r.icon} text-yellow`} aria-hidden /> {r.name}
                      </span>
                      <span className="text-enamel/85">
                        {lang === 'it' ? r.count : r.countEn} {t(strings.reviews.reviewsOn)} {r.name}
                      </span>
                      {r.name === 'Tripadvisor' && <span className="block text-sm text-enamel/85">{t(strings.reviews.tripRank)}</span>}
                    </span>
                  </Plate>
                </a>
              </li>
            ))}
          </ul>

          <div>
            <ul className="divide-y divide-green/15 border-y border-green/15">
              {reviews.map((r) => (
                <li key={r.author}>
                  <figure className="py-5">
                    <blockquote lang="it" className="text-xl leading-snug">“{r.text}”</blockquote>
                    <figcaption className="mt-2 font-semibold text-green">{r.author} · Google</figcaption>
                  </figure>
                </li>
              ))}
            </ul>
            {lang === 'en' && <p className="mt-3 text-sm text-muted">{t(strings.reviews.translatedNote)}</p>}
          </div>
        </div>
      </div>
    </section>
  )
}
