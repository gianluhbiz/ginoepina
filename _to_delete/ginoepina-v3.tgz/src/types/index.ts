export type Lang = 'it' | 'en'

/** Testo bilingue */
export interface L {
  it: string
  en: string
}

export interface MenuItem {
  name: string
  /** traduzione del nome, se utile ai turisti */
  nameEn?: string
  desc?: L
  /** prezzo in euro; assente = "chiedi in sala" */
  price?: number
  /** testo prezzo speciale (es. "da 7 a 10 €", "all'etto") */
  priceNote?: L
  /** numeri allergeni Reg. UE 1169/2011 (1–14) */
  allergens?: number[]
  /** file foto su Scoutmenu */
  img?: string
  /** specialità stagionale o non sempre disponibile */
  seasonal?: boolean
}

export interface MenuSection {
  id: string
  title: L
  note?: L
  items: MenuItem[]
}

export interface MenuCategory {
  id: string
  title: L
  icon: string
  intro?: L
  sections: MenuSection[]
}

export interface SetMenu {
  name: string
  price: number
  desc: L
}

export interface OpeningDay {
  /** 0 = domenica … 6 = sabato */
  day: number
  lunch: [string, string] | null
  dinner: [string, string] | null
}

export interface Space {
  id: string
  title: L
  text: L
  image: string
}

export interface Review {
  author: string
  text: string
}

export interface Faq {
  q: L
  a: L
}
