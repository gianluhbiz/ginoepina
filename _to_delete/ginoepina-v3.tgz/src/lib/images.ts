/**
 * Foto vere del locale.
 * - ginoepina.it: foto storiche, sale, piatti in evidenza
 * - scoutmenu.it: foto dei singoli piatti del menu digitale ufficiale
 * Per servirle in locale: `npm run images`, poi imposta le basi a '/images/…'.
 */
export const SITE_BASE = 'https://www.ginoepina.it/wp-content/uploads/'
export const MENU_BASE = 'https://www.scoutmenu.it/immagini/piatti/'

export const site = (path: string) => `${SITE_BASE}${path}`
export const menuPhoto = (file: string) => `${MENU_BASE}${file}`

export const photos = {
  historic: site('2023/10/FOTO-riserva-N-80-dal-1940-scaled-e1698655329184.jpg'),
  threeGenerations: site('2018/06/Tre-generazioni-pizzaioli.jpg'),
  fettuccine: site('2026/07/fettuccine-ai-funghi-porcini-pecorino.webp'),
  orecchiette: site('2026/07/orecchiette-melanzane-e-provolone.webp'),
  pizzaBanner: site('2023/11/pizza.jpg'),
  benevento: site('2016/03/slidehomenew.jpg'),
  awards: site('2026/07/riconoscimenti-e-attestati-2.webp'),
  // sale (menu digitale, 1280×720)
  sala: menuPhoto('697c856da13086.76860319piatti20260130T111818.350.jpg'),
  prive: menuPhoto('697c8581f37516.73983194piatti20260130T111707.471.jpg'),
  enoteca: menuPhoto('697c84ff31c6c5.55079350piatti20260130T111628.559.jpg'),
  dehors: menuPhoto('697c84710a8932.98678690piatti20260130T111406.328.jpg'),
  buffet: menuPhoto('69847e37c6a458.57478923FOTO1280x720px1280x720px20260205T122531.454.jpg'),
} as const
