import type { Transition } from 'framer-motion'

/** Poche animazioni, sempre rapide: curve forti in uscita, molla senza rimbalzo */
export const ease = [0.23, 1, 0.32, 1] as const
export const spring: Transition = { type: 'spring', duration: 0.4, bounce: 0.1 }
