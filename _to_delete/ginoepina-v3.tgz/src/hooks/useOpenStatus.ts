import { useEffect, useState } from 'react'
import { hours } from '../data/site'

const toMin = (t: string) => {
  const [h, m] = t.split(':').map(Number)
  return h * 60 + m
}

export type OpenStatus =
  | { kind: 'open'; until: string; today: number }
  | { kind: 'later'; at: string; today: number }
  | { kind: 'tomorrow'; at: string; today: number }

/** Aperto/chiuso calcolato sull'ora di Benevento (Europe/Rome), non su quella del visitatore */
export function getOpenStatus(date = new Date()): OpenStatus {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/Rome',
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date)
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? ''
  const day = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(get('weekday'))
  const mins = Number(get('hour')) * 60 + Number(get('minute'))

  const slot = hours.find((h) => h.day === day)
  const ranges = [slot?.lunch, slot?.dinner].filter(Boolean) as Array<[string, string]>
  for (const [a, b] of ranges) if (mins >= toMin(a) && mins < toMin(b)) return { kind: 'open', until: b, today: day }
  const next = ranges.find(([a]) => toMin(a) > mins)
  if (next) return { kind: 'later', at: next[0], today: day }
  const tomorrow = hours.find((h) => h.day === (day + 1) % 7)
  return { kind: 'tomorrow', at: tomorrow?.lunch?.[0] ?? '12:00', today: day }
}

export function useOpenStatus() {
  const [status, setStatus] = useState(getOpenStatus)
  useEffect(() => {
    const id = window.setInterval(() => setStatus(getOpenStatus()), 60_000)
    return () => window.clearInterval(id)
  }, [])
  return status
}
